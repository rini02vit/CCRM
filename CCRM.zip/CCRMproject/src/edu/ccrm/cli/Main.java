package edu.ccrm.cli;

import edu.ccrm.config.AppConfig;
import edu.ccrm.domain.*;
import edu.ccrm.io.BackupService;
import edu.ccrm.io.ImportExportService;
import edu.ccrm.service.*;
import edu.ccrm.util.CoursePredicates; // NEW: Import utility for filtering
import edu.ccrm.util.MaxCreditLimitExceededException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.function.Predicate; // NEW: Import for Stream API filtering
import java.util.stream.Collectors;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentService studentService = StudentService.getInstance();
    private static final CourseService courseService = CourseService.getInstance();
    private static final EnrollmentService enrollmentService = EnrollmentService.getInstance();
    private static final InstructorService instructorService = InstructorService.getInstance();
    private static final String DATA_PATH = AppConfig.getInstance().getDataPath();
    private static final String BACKUP_PATH = AppConfig.getInstance().getBackupPath();
    
    public static void main(String[] args) {
        System.out.println("Starting Campus Course & Records Manager (CCRM)...");
        AppConfig.getInstance().loadConfig();
    
        mainMenuLoop:
        while (true) {
            printMainMenu();
            String choice = scanner.nextLine();
            switch (choice) {
                case "1": manageStudents(); break;
                case "2": manageCourses(); break;
                case "3": manageEnrollmentAndGrades(); break;
                case "4": manageFileOperations(); break;
                case "5": manageInstructors(); break;
                case "6": generateReports(); break;
                case "7": System.out.println("Exiting CCRM. Goodbye!"); break mainMenuLoop;
                default: System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }

    private static void printMainMenu() {
        System.out.println("\n--- CCRM Main Menu ---");
        System.out.println("1. Manage Students");
        System.out.println("2. Manage Courses");
        System.out.println("3. Manage Enrollment & Grades");
        System.out.println("4. File Operations");
        System.out.println("5. Manage Instructors");
        System.out.println("6. Generate Reports");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");
    }
    
    private static void manageStudents() {
        System.out.println("\n--- Student Management ---");
        System.out.println("1. Add Student");
        System.out.println("2. View All Students");
        System.out.print("Enter choice: ");
        String choice = scanner.nextLine();
        
        switch (choice) {
            case "1":
                System.out.print("Enter student ID: ");
                String id = scanner.nextLine();
                System.out.print("Enter registration number: ");
                String regNo = scanner.nextLine();
                System.out.print("Enter full name: ");
                String name = scanner.nextLine();
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                studentService.addStudent(new Student(id, regNo, name, email));
                System.out.println("Student added successfully.");
                break;
            case "2":
                System.out.println("\n--- All Students ---");
                studentService.getAllStudents().forEach(Student::printProfile);
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void manageCourses() {
        System.out.println("\n--- Course Management ---");
        System.out.println("1. Add Course");
        System.out.println("2. View All Courses");
        System.out.println("3. Update Course"); // NEW
        System.out.println("4. Deactivate Course"); // NEW
        System.out.println("5. Search & Filter Courses"); // NEW
        System.out.print("Enter choice: ");
        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                addCourse(); 
                break;
            case "2":
                System.out.println("\n--- All Courses ---");
                courseService.getAllCourses().forEach(c -> System.out.println("Code: " + c.getCode() + ", Title: " + c.getTitle() + ", Department: " + c.getDepartment() + ", Semester: " + c.getSemester() + ", Instructor: " + (c.getInstructor() != null ? c.getInstructor().getFullName() : "N/A")));
                break;
            case "3":
                updateCourse(); // NEW
                break;
            case "4":
                deactivateCourse(); // NEW
                break;
            case "5":
                searchAndFilterCourses(); // NEW
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }
    
    // Extracted logic from manageCourses case 1
    private static void addCourse() {
        System.out.print("Enter course code: ");
        String code = scanner.nextLine();
        System.out.print("Enter course title: ");
        String title = scanner.nextLine();
        System.out.print("Enter course credits: ");
        int credits = 0;
        try {
            credits = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("Invalid credits input. Setting to 0.");
        }
        
        Semester semester = null;
        while (semester == null) {
            System.out.print("Enter semester (FALL, SPRING, SUMMER): ");
            String semesterInput = scanner.nextLine().toUpperCase();
            try {
                semester = Semester.valueOf(semesterInput);
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid semester. Please enter FALL, SPRING, or SUMMER.");
            }
        }
        
        System.out.print("Enter instructor ID: ");
        String instructorId = scanner.nextLine();
        Instructor instructor = instructorService.findById(instructorId).orElse(null);

        System.out.print("Enter department: "); // NEW: Prompt for department
        String department = scanner.nextLine();
        
        Course course = new Course.Builder(code)
            .title(title)
            .credits(credits)
            .semester(semester)
            .instructor(instructor)
            .department(department) // NEW: Pass department to builder
            .build();
        courseService.addCourse(course);
        System.out.println("Course added successfully.");
    }
    
    // NEW: Method to update a course
    private static void updateCourse() {
        System.out.print("Enter course code to update: ");
        String code = scanner.nextLine().toUpperCase();

        courseService.findByCode(code).ifPresentOrElse(oldCourse -> {
            System.out.println("--- Updating Course " + code + " ---");

            System.out.println("Current Title: " + oldCourse.getTitle());
            System.out.print("Enter new title (or press Enter to keep current): ");
            String newTitle = scanner.nextLine();
            newTitle = newTitle.isEmpty() ? oldCourse.getTitle() : newTitle;

            System.out.println("Current Credits: " + oldCourse.getCredits());
            System.out.print("Enter new credits (or press Enter to keep current): ");
            String creditsInput = scanner.nextLine();
            int newCredits = oldCourse.getCredits();
            if (!creditsInput.isEmpty()) {
                 try {
                    newCredits = Integer.parseInt(creditsInput);
                } catch (NumberFormatException e) {
                    System.err.println("Invalid credits input. Keeping current credits.");
                }
            }

            Semester newSemester = oldCourse.getSemester();
            System.out.println("Current Semester: " + oldCourse.getSemester());
            System.out.print("Enter new semester (FALL, SPRING, SUMMER, or Enter to keep current): ");
            String semesterInput = scanner.nextLine().toUpperCase();
            if (!semesterInput.isEmpty()) {
                try {
                    newSemester = Semester.valueOf(semesterInput);
                } catch (IllegalArgumentException e) {
                    System.err.println("Invalid semester input. Keeping current semester.");
                }
            }

            Instructor newInstructor = oldCourse.getInstructor();
            System.out.println("Current Instructor ID: " + (newInstructor != null ? newInstructor.getId() : "N/A"));
            System.out.print("Enter new Instructor ID (or press Enter to keep current): ");
            String instructorId = scanner.nextLine();
            if (!instructorId.isEmpty()) {
                newInstructor = instructorService.findById(instructorId).orElseGet(() -> {
                    System.err.println("Instructor not found. Keeping current instructor.");
                    return oldCourse.getInstructor();
                });
            }
            
            System.out.println("Current Department: " + oldCourse.getDepartment());
            System.out.print("Enter new Department (or press Enter to keep current): ");
            String newDepartment = scanner.nextLine();
            newDepartment = newDepartment.isEmpty() ? oldCourse.getDepartment() : newDepartment;


            boolean updated = courseService.updateCourse(code, newTitle, newCredits, newInstructor, newSemester, newDepartment);

            if (updated) {
                System.out.println("Course " + code + " updated successfully.");
            } else {
                System.err.println("Failed to update course (course code might be final).");
            }

        }, () -> System.out.println("Course with code " + code + " not found."));
    }

    // NEW: Method to logically deactivate a course
    private static void deactivateCourse() {
        System.out.print("Enter course code to deactivate: ");
        String code = scanner.nextLine().toUpperCase();
        
        boolean deactivated = courseService.deactivateCourse(code);
        
        if (deactivated) {
            System.out.println("Course " + code + " successfully deactivated.");
        } else {
            System.err.println("Course " + code + " not found or could not be deactivated.");
        }
    }
    
    // NEW: Method to search and filter courses using Stream API
    private static void searchAndFilterCourses() {
        System.out.println("\n--- Course Search & Filter ---");
        
        // Start with a predicate that accepts everything
        Predicate<Course> finalPredicate = course -> true;

        // 1. Filter by Department
        System.out.print("Filter by Department (e.g., CS, MATH, or Enter to skip): ");
        String dept = scanner.nextLine().trim();
        if (!dept.isEmpty()) {
            finalPredicate = finalPredicate.and(CoursePredicates.inDepartment(dept));
        }
        
        // 2. Filter by Semester
        System.out.print("Filter by Semester (FALL, SPRING, SUMMER, or Enter to skip): ");
        String semesterInput = scanner.nextLine().trim().toUpperCase();
        if (!semesterInput.isEmpty()) {
            try {
                Semester semester = Semester.valueOf(semesterInput);
                finalPredicate = finalPredicate.and(CoursePredicates.inSemester(semester));
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid semester input. Skipping semester filter.");
            }
        }

        // 3. Filter by Instructor ID
        System.out.print("Filter by Instructor ID (e.g., I101, or Enter to skip): ");
        String instructorId = scanner.nextLine().trim();
        if (!instructorId.isEmpty()) {
            Instructor instructor = instructorService.findById(instructorId).orElse(null);
            if (instructor != null) {
                finalPredicate = finalPredicate.and(CoursePredicates.hasInstructor(instructor));
            } else {
                System.out.println("Instructor not found. Skipping instructor filter.");
            }
        }
        
        System.out.println("\n--- Filter Results ---");
        if (courseService.searchAndFilterCourses(finalPredicate).isEmpty()) {
            System.out.println("No courses found matching the criteria.");
        } else {
            courseService.searchAndFilterCourses(finalPredicate).forEach(c -> 
                System.out.println("Code: " + c.getCode() + 
                                   ", Title: " + c.getTitle() + 
                                   ", Dept: " + c.getDepartment() + 
                                   ", Semester: " + c.getSemester() + 
                                   ", Instructor: " + (c.getInstructor() != null ? c.getInstructor().getFullName() : "N/A"))
            );
        }
    }
    
    private static void manageInstructors() {
        System.out.println("\n--- Instructor Management ---");
        System.out.println("1. Add Instructor");
        System.out.println("2. View All Instructors");
        System.out.print("Enter choice: ");
        String choice = scanner.nextLine();
        
        switch (choice) {
            case "1":
                System.out.print("Enter instructor ID: ");
                String id = scanner.nextLine();
                System.out.print("Enter full name: ");
                String name = scanner.nextLine();
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                instructorService.addInstructor(new Instructor(id, name, email));
                System.out.println("Instructor added successfully.");
                break;
            case "2":
                System.out.println("\n--- All Instructors ---");
                instructorService.getAllInstructors().forEach(i -> System.out.println("ID: " + i.getId() + ", Name: " + i.getFullName() + ", Email: " + i.getEmail()));
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void manageEnrollmentAndGrades() {
        System.out.println("\n--- Enrollment & Grading Menu ---");
        System.out.println("1. Enroll Student");
        System.out.println("2. Record Marks");
        System.out.println("3. Print Transcript");
        System.out.println("4. Unenroll Student"); // NEW
        System.out.print("Enter choice: ");
        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                enrollStudent();
                break;
            case "2":
                recordMarks();
                break;
            case "3":
                printTranscript();
                break;
            case "4":
                unenrollStudent(); // NEW
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }
    
    // NEW: Method to unenroll a student from a course
    private static void unenrollStudent() {
        System.out.print("Enter student Reg No to unenroll: ");
        String regNo = scanner.nextLine();
        System.out.print("Enter course code to drop: ");
        String courseCode = scanner.nextLine();
        
        // This method relies on the updated EnrollmentService.unenrollStudent()
        if (enrollmentService.unenrollStudent(regNo, courseCode)) {
            System.out.println("Successfully unenrolled student " + regNo + " from course " + courseCode + ".");
        } else {
            System.err.println("Unenrollment failed. Check student Reg No and course code.");
        }
    }


    private static void manageFileOperations() {
        System.out.println("\n--- File Operations ---");
        System.out.println("1. Import Students");
        System.out.println("2. Import Courses");
        System.out.println("3. Import Instructors");
        System.out.println("4. Export Data");
        System.out.println("5. Backup Data");
        System.out.println("6. Show Backup Directory Size");
        System.out.print("Enter choice: ");
        String choice = scanner.nextLine();
        
        try {
            switch(choice) {
                case "1":
                    ImportExportService.importStudents(Paths.get(DATA_PATH, "students.csv"));
                    System.out.println("Students imported successfully.");
                    break;
                case "2":
                    ImportExportService.importCourses(Paths.get(DATA_PATH, "courses.csv"));
                    System.out.println("Courses imported successfully.");
                    break;
                case "3":
                    ImportExportService.importInstructors(Paths.get(DATA_PATH, "instructors.csv"));
                    System.out.println("Instructors imported successfully.");
                    break;
                case "4":
                    Files.createDirectories(Paths.get(DATA_PATH));
                    ImportExportService.exportStudents(Paths.get(DATA_PATH, "students.csv"));
                    ImportExportService.exportCourses(Paths.get(DATA_PATH, "courses.csv"));
                    ImportExportService.exportInstructors(Paths.get(DATA_PATH, "instructors.csv"));
                    System.out.println("Data exported successfully.");
                    break;
                case "5":
                    Path sourceDir = Paths.get(DATA_PATH);
                    Path backupParentDir = Paths.get(BACKUP_PATH);
                    BackupService.createBackup(sourceDir, backupParentDir);
                    break;
                case "6":
                    long size = BackupService.getDirectorySize(Paths.get(BACKUP_PATH));
                    System.out.printf("Total size of backup directory: %.2f MB%n", (double) size / 1024 / 1024);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } catch (IOException e) {
            System.err.println("File I/O error: " + e.getMessage());
        }
    }
    
    private static void generateReports() {
        System.out.println("\n--- GPA Distribution Report ---");
        
        enrollmentService.getAllEnrollments().stream()
            .collect(Collectors.groupingBy(e -> e.getStudent().getRegNo(), 
                Collectors.averagingDouble(e -> e.getGrade().getGradePoint())))
            .forEach((regNo, gpa) -> System.out.printf("Reg No: %s, GPA: %.2f%n", regNo, gpa));
    }
    
    private static void enrollStudent() {
        System.out.print("Enter student Reg No: ");
        String regNo = scanner.nextLine();
        System.out.print("Enter course code: ");
        String courseCode = scanner.nextLine();
        
        studentService.findByRegNo(regNo).ifPresent(student -> {
            courseService.findByCode(courseCode).ifPresent(course -> {
                try {
                    enrollmentService.enrollStudent(student, course);
                    System.out.println("Student " + regNo + " enrolled in " + courseCode);
                } catch (MaxCreditLimitExceededException e) {
                    System.err.println("Enrollment failed: " + e.getMessage());
                }
            });
        });
    }

    private static void recordMarks() {
        System.out.print("Enter student Reg No: ");
        String regNo = scanner.nextLine();
        System.out.print("Enter course code: ");
        String courseCode = scanner.nextLine();
        System.out.print("Enter marks: ");
        double marks = scanner.nextDouble();
        scanner.nextLine(); // consume newline
        
        enrollmentService.recordMarks(regNo, courseCode, marks);
        System.out.println("Marks recorded successfully.");
    }
    
    private static void printTranscript() {
        System.out.print("Enter student registration number to print transcript: ");
        String regNo = scanner.nextLine();
        
        studentService.findByRegNo(regNo).ifPresentOrElse(student -> {
            System.out.println("\n--- Transcript for " + student.getFullName() + " ---");
            student.getEnrolledCourses().forEach(enrollment -> {
                System.out.println(enrollment.getCourse().getTitle() + " - Marks: " + enrollment.getMarks() + ", Grade: " + enrollment.getGrade());
            });
            
            double totalGradePoints = student.getEnrolledCourses().stream()
                .mapToDouble(e -> e.getGrade().getGradePoint() * e.getCourse().getCredits())
                .sum();
            
            int totalCredits = student.getEnrolledCourses().stream()
                .mapToInt(e -> e.getCourse().getCredits())
                .sum();

            if (totalCredits > 0) {
                double gpa = totalGradePoints / totalCredits;
                System.out.printf("Total GPA: %.2f%n", gpa);
            } else {
                System.out.println("No grades recorded yet.");
            }
        }, () -> System.out.println("Student not found."));
    }
}