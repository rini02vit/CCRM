package edu.ccrm.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class AppConfig {
    private static AppConfig instance;
    private Properties properties;

    private AppConfig() {
        this.properties = new Properties();
    }

    public static AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }

    public void loadConfig() {
        // Load configuration from a file or set defaults
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("application.properties")) {
            if (input == null) {
                System.out.println("No application.properties found. Using defaults.");
                properties.setProperty("data.path", "data");
                properties.setProperty("backup.path", "backup");
            } else {
                properties.load(input);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public String getDataPath() {
        return properties.getProperty("data.path", "data");
    }

    public String getBackupPath() {
        return properties.getProperty("backup.path", "backup");
    }
}