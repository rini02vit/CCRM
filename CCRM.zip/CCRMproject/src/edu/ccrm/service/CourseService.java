// File: src/edu/ccrm/service/CourseService.java

package edu.ccrm.service;

import edu.ccrm.domain.Course;
import edu.ccrm.domain.Instructor;
import edu.ccrm.domain.Semester; // NEW import
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap; // Use ConcurrentHashMap for thread safety
import java.util.function.Predicate; // NEW import for filtering
import java.util.stream.Collectors;

public class CourseService {
    private static CourseService instance;
    // REFACOR: Change List to Map for O(1) lookups, updates, and removals
    private final Map<String, Course> courseMap; 

    private CourseService() {
        this.courseMap = new ConcurrentHashMap<>(); // Initialize the Map
    }

    public static CourseService getInstance() {
        if (instance == null) {
            instance = new CourseService();
        }
        return instance;
    }

    // REFACOR: Use map put
    public void addCourse(Course course) {
        courseMap.put(course.getCode(), course); 
    }
    
    // REFACOR: Get values from map
    public List<Course> getAllCourses() {
        return new ArrayList<>(courseMap.values());
    }

    // REFACOR: Use map get
    public Optional<Course> findByCode(String code) {
        return Optional.ofNullable(courseMap.get(code));
    }
    
    // Kept for compatibility, but the new search method is better
    public List<Course> searchByInstructor(Instructor instructor) {
        return courseMap.values().stream()
            .filter(c -> c.getInstructor() != null && c.getInstructor().equals(instructor))
            .collect(Collectors.toList());
    }
    
    // NEW: updateCourse implementation
    public boolean updateCourse(String courseCode, String newTitle, int newCredits, Instructor newInstructor, Semester newSemester, String newDepartment) {
        return findByCode(courseCode).map(course -> {
            // Create a NEW Course object to replace the old one (due to final code)
            Course newCourse = new Course.Builder(courseCode)
                .title(newTitle)
                .credits(newCredits)
                .instructor(newInstructor)
                .semester(newSemester)
                .department(newDepartment)
                .build();
            
            this.courseMap.put(courseCode, newCourse); // Replace the course in the map
            return true;
        }).orElse(false);
    }

    // NEW: deactivateCourse implementation
    public boolean deactivateCourse(String courseCode) {
        return findByCode(courseCode).map(course -> {
            // Logical deactivation by updating the course's title
            Course updatedCourse = new Course.Builder(courseCode)
                .title(course.getTitle() + " (DEACTIVATED)")
                .credits(course.getCredits())
                .instructor(course.getInstructor())
                .semester(course.getSemester())
                .department(course.getDepartment())
                .build();

            this.courseMap.put(courseCode, updatedCourse);
            return true;
        }).orElse(false);
    }

    // NEW: Search and Filter implementation using Stream API
    public List<Course> searchAndFilterCourses(Predicate<Course> filter) {
        if (filter == null) {
            filter = course -> true;
        }
        
        return courseMap.values().stream()
                .filter(filter)
                .collect(Collectors.toList());
    }
}