package edu.ccrm.service;

import edu.ccrm.domain.Student;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StudentService {
    private static StudentService instance;
    private List<Student> students;

    private StudentService() {
        this.students = new ArrayList<>();
    }

    public static StudentService getInstance() {
        if (instance == null) {
            instance = new StudentService();
        }
        return instance;
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public List<Student> getAllStudents() {
        return new ArrayList<>(students); // Defensive copying
    }
    
    public Optional<Student> findByRegNo(String regNo) {
        return students.stream()
            .filter(s -> s.getRegNo().equals(regNo))
            .findFirst();
    }
}