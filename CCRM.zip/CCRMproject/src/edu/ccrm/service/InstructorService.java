package edu.ccrm.service;

import edu.ccrm.domain.Instructor;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InstructorService {
    private static InstructorService instance;
    private List<Instructor> instructors;

    private InstructorService() {
        this.instructors = new ArrayList<>();
    }

    public static InstructorService getInstance() {
        if (instance == null) {
            instance = new InstructorService();
        }
        return instance;
    }

    public void addInstructor(Instructor instructor) {
        instructors.add(instructor);
    }

    public List<Instructor> getAllInstructors() {
        return new ArrayList<>(instructors);
    }

    public Optional<Instructor> findById(String id) {
        return instructors.stream()
            .filter(i -> i.getId().equals(id))
            .findFirst();
    }
}