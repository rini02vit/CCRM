package edu.ccrm.service;

import edu.ccrm.domain.Course;
import edu.ccrm.domain.Enrollment;
import edu.ccrm.domain.Student;
import edu.ccrm.util.DuplicateEnrollmentException;
import edu.ccrm.util.MaxCreditLimitExceededException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Map; // NEW
import java.util.concurrent.ConcurrentHashMap; // NEW

public class EnrollmentService {
    private static EnrollmentService instance;
    // REFATOR: Change List to Map for O(1) lookups, updates, and removals
    private final Map<String, Enrollment> enrollmentMap;
    private static final int MAX_CREDITS_PER_SEMESTER = 21;
    
    // For unenrollment, we need access to StudentService
    private final StudentService studentService = StudentService.getInstance(); 

    private EnrollmentService() {
        // Initialize the Map
        this.enrollmentMap = new ConcurrentHashMap<>();
    }

    public static EnrollmentService getInstance() {
        if (instance == null) {
            instance = new EnrollmentService();
        }
        return instance;
    }

    // REFATOR: Get values from map
    public List<Enrollment> getAllEnrollments() {
        return new ArrayList<>(enrollmentMap.values());
    }

    public void enrollStudent(Student student, Course course) throws MaxCreditLimitExceededException {
        // Use a composite key for O(1) lookup
        String enrollmentKey = student.getRegNo() + "-" + course.getCode();
        
        // Business rule: Check if student is already enrolled in the course (O(1) lookup)
        if (enrollmentMap.containsKey(enrollmentKey)) {
             throw new DuplicateEnrollmentException("Student " + student.getRegNo() + " is already enrolled in course " + course.getCode());
        }

        // Business rule: Check max credits per semester
        int currentCredits = student.getEnrolledCourses().stream()
            .mapToInt(e -> e.getCourse().getCredits())
            .sum();
        
        if (currentCredits + course.getCredits() > MAX_CREDITS_PER_SEMESTER) {
            throw new MaxCreditLimitExceededException("Cannot enroll. Max credit limit of " + MAX_CREDITS_PER_SEMESTER + " exceeded.");
        }

        Enrollment enrollment = new Enrollment(student, course);
        
        // Store and track enrollment in the map
        enrollmentMap.put(enrollmentKey, enrollment);
        
        // Student's internal list must still be updated
        student.addEnrollment(enrollment); 
    }

    // REFATOR: Use Map for O(1) lookup
    public void recordMarks(String studentRegNo, String courseCode, double marks) {
        String enrollmentKey = studentRegNo + "-" + courseCode;
        
        // O(1) lookup using the key
        Enrollment enrollment = enrollmentMap.get(enrollmentKey);

        if (enrollment != null) {
            enrollment.setMarks(marks);
            System.out.println("Marks recorded successfully for " + studentRegNo + " in " + courseCode);
        } else {
            System.err.println("Error: Student " + studentRegNo + " is not enrolled in course " + courseCode);
        }
    }
    
    /**
     * Removes an enrollment from the central service map and the student's internal list.
     */
    public boolean unenrollStudent(String studentRegNo, String courseCode) {
        Student student = studentService.findByRegNo(studentRegNo).orElse(null);
        
        if (student == null) {
            System.out.println("Error: Student with RegNo " + studentRegNo + " not found.");
            return false;
        }

        String enrollmentKey = studentRegNo + "-" + courseCode;

        // 1. Remove from central enrollment map (O(1))
        Enrollment removedEnrollment = enrollmentMap.remove(enrollmentKey);

        if (removedEnrollment != null) {
            // 2. Remove the enrollment from the Student's internal list
            // This relies on Student.java being updated with unenrollCourse(courseCode)
            student.unenrollCourse(courseCode); 
            
            System.out.println("Student " + studentRegNo + " successfully unenrolled from " + courseCode + ".");
            return true;
        }

        System.out.println("Error: Student " + studentRegNo + " was not enrolled in " + courseCode + ".");
        return false;
    }
}