package edu.ccrm.domain;

public class Course {
    private final String code;
    private String title;
    private int credits;
    private Instructor instructor;
    private Semester semester;
    private String department;

    private Course(Builder builder) {
        this.code = builder.code;
        this.title = builder.title;
        this.credits = builder.credits;
        this.instructor = builder.instructor;
        this.semester = builder.semester;
        this.department = builder.department;
    }

    public String getCode() { return code; }
    public String getTitle() { return title; }
    public int getCredits() { return credits; }
    public Instructor getInstructor() { return instructor; }
    public Semester getSemester() { return semester; }
    public String getDepartment() { return department; }

    @Override
    public String toString() {
        return String.format("%s,%s,%d,%s,%s,%s", this.code, this.title, this.credits, 
            this.instructor != null ? this.instructor.getId() : "", 
            this.semester != null ? this.semester.name() : "", 
            this.department != null ? this.department : "");
    }

    public static class Builder {
        private final String code;
        private String title;
        private int credits;
        private Instructor instructor;
        private Semester semester;
        private String department;

        public Builder(String code) { this.code = code; }
        public Builder title(String title) { this.title = title; return this; }
        public Builder credits(int credits) { this.credits = credits; return this; }
        public Builder instructor(Instructor instructor) { this.instructor = instructor; return this; }
        public Builder semester(Semester semester) { this.semester = semester; return this; }
        public Builder department(String department) { this.department = department; return this; }

        public Course build() {
            // Assertion for invariant: non-null code and positive credits
            assert code != null && !code.isEmpty() : "Course code must not be null or empty";
            assert credits > 0 : "Credits must be a positive number";
            return new Course(this);
        }
    }
}