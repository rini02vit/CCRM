package edu.ccrm.domain;

import java.time.LocalDateTime;

public class Enrollment {
    private final Student student;
    private final Course course;
    private double marks;
    private Grade grade;
    private final LocalDateTime enrollmentDate;

    public Enrollment(Student student, Course course) {
        this.student = student;
        this.course = course;
        this.enrollmentDate = LocalDateTime.now();
        this.marks = 0.0;
        this.grade = Grade.NA;
    }

    public Student getStudent() { return student; }
    public Course getCourse() { return course; }
    public double getMarks() { return marks; }
    public Grade getGrade() { return grade; }
    public LocalDateTime getEnrollmentDate() { return enrollmentDate; }

    public void setMarks(double marks) {
        this.marks = marks;
        this.grade = Grade.fromMarks(marks);
    }
    
    @Override
    public String toString() {
        return String.format("%s,%s,%.2f,%s", this.student.getRegNo(), this.course.getCode(), this.marks, this.grade.name());
    }
}