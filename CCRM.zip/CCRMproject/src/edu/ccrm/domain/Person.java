package edu.ccrm.domain;

import java.time.LocalDateTime;

public abstract class Person {
    protected String id;
    protected String fullName;
    protected String email;
    protected LocalDateTime dateCreated;

    public Person(String id, String fullName, String email) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.dateCreated = LocalDateTime.now();
    }

    public String getId() { return id; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public LocalDateTime getDateCreated() { return dateCreated; }

    public abstract void printProfile();

    @Override
    public String toString() {
        return "Person [id=" + id + ", fullName=" + fullName + ", email=" + email + "]";
    }
}