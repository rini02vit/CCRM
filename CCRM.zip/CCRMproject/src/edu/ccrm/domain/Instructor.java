package edu.ccrm.domain;

public class Instructor extends Person {
    private String department;

    public Instructor(String id, String fullName, String email) {
        super(id, fullName, email);
    }

    public String getDepartment() { return department; }

    @Override
    public void printProfile() {
        System.out.println("--- Instructor Profile ---");
        System.out.println("ID: " + this.id);
        System.out.println("Full Name: " + this.fullName);
        System.out.println("Email: " + this.email);
        System.out.println("Department: " + this.department);
        System.out.println("Date Created: " + this.dateCreated);
    }
    
    @Override
    public String toString() {
        return String.format("%s,%s,%s,%s", this.id, this.fullName, this.email, this.department);
    }
}