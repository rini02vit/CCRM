package edu.ccrm.domain;
import java.util.ArrayList;
import java.util.List;

public class Student extends Person {
    private String regNo;
    private final String status; // Add final
    private final List<Enrollment> enrolledCourses; // Add final

    public Student(String id, String regNo, String fullName, String email) {
        super(id, fullName, email);
        this.regNo = regNo;
        this.status = "ACTIVE";
        this.enrolledCourses = new ArrayList<>();
    }

    public String getRegNo() { return regNo; }
    public String getStatus() { return status; }
    public List<Enrollment> getEnrolledCourses() { return enrolledCourses; }

    public void enrollCourse(Course course) {
        this.enrolledCourses.add(new Enrollment(this, course));
    }

    public void addEnrollment(Enrollment enrollment) {
        this.enrolledCourses.add(enrollment);
    }

    @Override
    public void printProfile() {
        System.out.println("--- Student Profile ---");
        System.out.println("ID: " + this.id);
        System.out.println("Reg No: " + this.regNo);
        System.out.println("Full Name: " + this.fullName);
        System.out.println("Email: " + this.email);
        System.out.println("Status: " + this.status);
        System.out.println("Date Created: " + this.dateCreated);
        System.out.println("Enrolled Courses: " + enrolledCourses.size());
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,%s,%s", this.id, this.regNo, this.fullName, this.email, this.status);
    }

    public boolean unenrollCourse(String courseCode) {
        return this.enrolledCourses.removeIf(enrollment -> 
        enrollment.getCourse().getCode().equals(courseCode)
    );
}
}