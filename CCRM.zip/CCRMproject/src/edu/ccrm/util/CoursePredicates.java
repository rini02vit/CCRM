// File: src/edu/ccrm/util/CoursePredicates.java
package edu.ccrm.util;

import edu.ccrm.domain.Course;
import edu.ccrm.domain.Semester;
import edu.ccrm.domain.Instructor;
import java.util.function.Predicate;

public class CoursePredicates {

    // Filter by Instructor
    public static Predicate<Course> hasInstructor(Instructor instructor) {
        return course -> course.getInstructor() != null && 
                         course.getInstructor().equals(instructor);
    }
    
    // Filter by Department (case-insensitive contains)
    public static Predicate<Course> inDepartment(String department) {
        if (department == null || department.trim().isEmpty()) {
            return course -> true; // No filter
        }
        final String lowerDepartment = department.toLowerCase();
        return course -> course.getDepartment() != null &&
                         course.getDepartment().toLowerCase().contains(lowerDepartment);
    }

    // Filter by Semester
    public static Predicate<Course> inSemester(Semester semester) {
        if (semester == null) {
            return course -> true; // No filter
        }
        return course -> course.getSemester() == semester;
    }

    // A method to combine multiple predicates (AND logic)
    @SafeVarargs
    public static Predicate<Course> combine(Predicate<Course>... predicates) {
        Predicate<Course> combined = course -> true;
        for (Predicate<Course> p : predicates) {
            combined = combined.and(p);
        }
        return combined;
    }
}