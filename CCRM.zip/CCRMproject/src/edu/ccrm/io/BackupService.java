package edu.ccrm.io;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BackupService {
    
    public static void createBackup(Path sourceDir, Path backupParentDir) throws IOException {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        Path backupDir = backupParentDir.resolve("backup_" + timestamp);
        Files.createDirectories(backupDir);
        
        try (var walk = Files.walk(sourceDir)) {
            walk.forEach(source -> {
                try {
                    Path destination = backupDir.resolve(sourceDir.relativize(source));
                    if (Files.isDirectory(source)) {
                        Files.createDirectories(destination);
                    } else {
                        Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
                    }
                } catch (IOException e) {
                    System.err.println("Failed to copy file: " + source + " -> " + e.getMessage());
                }
            });
        }
        System.out.println("Backup created at: " + backupDir);
    }

    // Recursive utility to calculate directory size
    public static long getDirectorySize(Path dir) throws IOException {
        if (!Files.exists(dir) || !Files.isDirectory(dir)) {
            return 0L;
        }
        
        long[] size = {0L};
        Files.walkFileTree(dir, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                size[0] += attrs.size();
                return FileVisitResult.CONTINUE;
            }
        });
        return size[0];
    }
}