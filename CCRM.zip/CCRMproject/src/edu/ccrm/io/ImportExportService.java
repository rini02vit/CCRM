package edu.ccrm.io;

import edu.ccrm.domain.Course;
import edu.ccrm.domain.Enrollment;
import edu.ccrm.domain.Instructor;
import edu.ccrm.domain.Semester;
import edu.ccrm.domain.Student;
import edu.ccrm.service.CourseService;
import edu.ccrm.service.EnrollmentService;
import edu.ccrm.service.InstructorService;
import edu.ccrm.service.StudentService;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;

public class ImportExportService {

    public static void importStudents(Path filePath) throws IOException {
        System.out.println("Importing students from " + filePath);
        StudentService studentService = StudentService.getInstance();
        
        Files.lines(filePath) // Use Files.lines() for an efficient stream of lines
             .map(line -> line.split(",")) // Split each line by comma
             .filter(parts -> parts.length >= 4) // Ensure the line is not malformed
             .forEach(parts -> {
                 studentService.addStudent(new Student(parts[0], parts[1], parts[2], parts[3]));
             });
             
        System.out.println("Students imported successfully.");
    }

// Inside your ImportExportService.java file

public static void importCourses(Path filePath) throws IOException {
    System.out.println("Importing courses from " + filePath);
    CourseService courseService = CourseService.getInstance();
    InstructorService instructorService = InstructorService.getInstance();
    
    Files.lines(filePath)
         .map(line -> line.split(","))
         .filter(parts -> parts.length >= 6) // Ensure the line has all 6 parts
         .forEach(parts -> {
             try {
                 String code = parts[0];
                 String title = parts[1];
                 int credits = Integer.parseInt(parts[2]);
                 String instructorId = parts[3];
                 Semester semester = Semester.valueOf(parts[4].toUpperCase());
                 String department = parts[5];

                 // Find the instructor by ID from the instructor service
                 Instructor instructor = instructorService.findById(instructorId).orElse(null);

                 // Use the Builder to create a new Course object
                 Course course = new Course.Builder(code)
                     .title(title)
                     .credits(credits)
                     .instructor(instructor)
                     .semester(semester)
                     .department(department)
                     .build();
                 
                 courseService.addCourse(course);
             } catch (Exception e) {
                 System.err.println("Skipping invalid course data: " + String.join(",", parts) + " - Error: " + e.getMessage());
             }
         });
         
    System.out.println("Courses imported successfully.");
}

    public static void exportStudents(Path filePath) throws IOException {
        List<String> studentLines = StudentService.getInstance().getAllStudents().stream()
                .map(Student::toString)
                .collect(Collectors.toList());
        Files.write(filePath, studentLines);
    }
    
    public static void exportCourses(Path filePath) throws IOException {
        List<String> courseLines = CourseService.getInstance().getAllCourses().stream()
                .map(Course::toString)
                .collect(Collectors.toList());
        Files.write(filePath, courseLines);
    }
    
    public static void exportEnrollments(Path filePath) throws IOException {
        List<String> enrollmentLines = EnrollmentService.getInstance().getAllEnrollments().stream()
                .map(Enrollment::toString)
                .collect(Collectors.toList());
        Files.write(filePath, enrollmentLines);
    }
     public static void importInstructors(Path filePath) throws IOException {
        System.out.println("Importing instructors from " + filePath);
        InstructorService instructorService = InstructorService.getInstance();
        
        Files.lines(filePath)
             .map(line -> line.split(","))
             .filter(parts -> parts.length >= 3)
             .forEach(parts -> {
                 instructorService.addInstructor(new Instructor(parts[0], parts[1], parts[2]));
             });
             
        System.out.println("Instructors imported successfully.");
    }
    
    public static void exportInstructors(Path filePath) throws IOException {
        List<String> instructorLines = InstructorService.getInstance().getAllInstructors().stream()
                .map(Instructor::toString)
                .collect(Collectors.toList());
        Files.write(filePath, instructorLines);
    }
}